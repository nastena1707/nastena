﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll;
using System.Collections;
using Dll;

namespace Test
{
    class Program
    {         
        static void Main(string[] args)
        {

          /*  Console.WriteLine("==== Missionaries and Cannibals Problem ====");
            Console.WriteLine("Choose the search method: ");
            Console.WriteLine("\t 1. Breadth-first search");
            Console.WriteLine("\t 2. Depth-limited search");
            Console.WriteLine("\nType your choice and press ENTER: ");

            string optionStr = Console.ReadLine();
         

            int option = int.Parse(optionStr);
            State initialState = new State(3, 3, Position.LEFT, 0, 0);
            switch (option)
            {
                case 1:
                    executeBFS(initialState);
                    break;
                case 2:
                    executeDLS(initialState);
                    break;
            }
        }

        private static void executeBFS(State initialState)
        {
            BreadthFirstSearch search = new BreadthFirstSearch();
            State solution = search.exec(initialState);
            printSolution(solution);
        }

       private static void executeDLS(State initialState)
        {
            DepthLimitedSearch search = new DepthLimitedSearch();
            State solution = search.exec(initialState);
            printSolution(solution);
        }

        private static void printSolution(State solution)
        {
            if (null == solution)
            {
                Console.WriteLine("\nNo solution found.");
            }
            else {
                Console.WriteLine("\nSolution (cannibalLeft,missionaryLeft,boat,cannibalRight,missionaryRight): ");
                List<State> path = new List<State>();
                State state = solution;
                while (null != state)
                {
                    path.Add(state);
                    state = state.getParentState();
                }

                int depth = path.Count() - 1;
                for (int i = depth; i >= 0; i--)
                {
                    state = path[i];
                    if (state.isGoal())
                    {
                        Console.Write(state.ToString());
                    }
                    else {
                        Console.WriteLine(state.ToString() + " -> ");
                    }
                }
                Console.WriteLine("\nDepth: " + depth);
            }
            Console.ReadKey();*/
        }         
    }
}
