﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dll;

namespace Form_main
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void but_help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Задача о миссионерах и людоедах. Три миссионера и три людоеда должны пересечь реку на лодке, способной выдержать не более двух человек. При этом на одном берегу не может оставаться больше людоедов, чем миссионеров (иначе миссионеров съедят). Лодка также не может пересечь реку без людей на борту.", "Условие задачи", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void but_start_Click(object sender, EventArgs e)
        {
            State initialState = new State(3, 3, Position.LEFT, 0, 0);
            switch (comboBox2.Text)
            {
                case "R":
                    initialState = new State(int.Parse(textBox_c1.Text), int.Parse(textBox_m1.Text), Position.RIGHT, int.Parse(textBox_c2.Text), int.Parse(textBox_m2.Text));
                    break;
                case "L":
                    initialState = new State(int.Parse(textBox_c1.Text), int.Parse(textBox_m1.Text), Position.LEFT, int.Parse(textBox_c2.Text), int.Parse(textBox_m2.Text));
                    break;
            }

            switch (comboBox1.Text)
            {
                case "BFS":
                    executeBFS(initialState,textBox_result);
                    break;
                case "DLS":
                    executeDLS(initialState,textBox_result);
                    break;
            }
        }

        private static void executeBFS(State initialState,TextBox t)
        {
            System.Diagnostics.Stopwatch myStopwatch = new System.Diagnostics.Stopwatch();
            myStopwatch.Start();
            BreadthFirstSearch search = new BreadthFirstSearch();
            State solution = search.exec(initialState);
            myStopwatch.Stop();
            t.Text = "Time: " + myStopwatch.ElapsedTicks.ToString()+"\r\n";
            printSolution(solution,t);
        }

        private static void executeDLS(State initialState,TextBox t)
        {
            System.Diagnostics.Stopwatch myStopwatch = new System.Diagnostics.Stopwatch();
            myStopwatch.Start();
            DepthLimitedSearch search = new DepthLimitedSearch();
            State solution = search.exec(initialState);
            myStopwatch.Stop();
            t.Text = "Time: " + myStopwatch.ElapsedTicks.ToString()+"\r\n";
            printSolution(solution,t);
        }

        private static void printSolution(State solution,TextBox t)
        {
            if (null == solution)
            {
                t.Text +="\nNo solution found.";
            }
            else {
                List<State> path = new List<State>();
                State state = solution;
                while (null != state)
                {
                    path.Add(state);
                    state = state.getParentState();
                }
       
                int depth = path.Count() - 1;
                for (int i = depth; i >= 0; i--)
                {
                    state = path[i];
                    if (state.isGoal())
                    {
                        t.Text += state.ToString();
                    }
                    else {
                        t.Text += state.ToString() + " -> \r\n";
                    }
                }
                t.Text += "\r\nDepth: " + depth;

            }
        }
    }
}
